import pathlib
import pymupdf as fitz
import re
import requests

# uv pip install pymupdf requests


def pdf_extract_pages(in_fname, out_fname, start_page, end_page):
    pdf = fitz.open(in_fname)
    new_pdf = fitz.open()
    new_pdf.insert_pdf(pdf, from_page=0, to_page=0)
    new_pdf.save(out_fname)
    new_pdf.close()
    pdf.close()


def pdf_extract_cover(in_fname, out_fname):
    pdf_extract_pages(in_fname, out_fname, 0, 0)


def extract_all_covers(folder_name, output_prefix):
    flist = pathlib.Path(folder_name).glob("*.pdf")
    for i, in_fname in enumerate(flist):
        out_fname = f"{output_prefix}_{i:02d}.pdf"
        pdf_extract_cover(in_fname, out_fname)


def extract_doi(in_fname):
    DOI_PATTERN = re.compile(r'\b10\.\d{4,9}/[^\s"<>]+', re.IGNORECASE)

    pdf = fitz.open(in_fname)
    txt = pdf[0].get_text()
    pdf.close()

    matches = DOI_PATTERN.findall(txt)
    doi = "NOT FOUND"
    if len(matches) > 0:
        doi = matches[0]

    return doi.strip()


def extract_doi_in_folder(folder_name):
    dois = {}
    flist = pathlib.Path(folder_name).glob("*.pdf")
    for i, in_fname in enumerate(flist):
        doi = extract_doi(in_fname)
        dois[str(in_fname)] = doi

    return dois


def get_bibtex(doi):
    url = f"https://doi.org/{doi}"
    rsp = requests.get(url, headers={"Accept": "application/x-bibtex"})
    if rsp.status_code == 200:
        bibtex = rsp.content.decode("utf8")
    else:
        bibtex = "fetch failed"
    return doi, bibtex


def make_bibtex_db(dois, db_fname="references.bib"):
    bibtexs = {}
    for fname, doi in dois.items():
        if doi not in "NOT FOUND":
            doi, bibtex = get_bibtex(doi)
            bibtexs[fname] = bibtex
            print(fname, doi, bibtex[:30])

    with open(db_fname, "w") as f:
        for fname, bibtex in bibtexs.items():
            if bibtex not in "fetch failed":
                msg = f"{bibtex}\n\n"
                f.write(msg)
                print(msg)


##################################
######## MAIN PROGRAMME ##########
##################################

extract_all_covers(folder_name="LSP refrences", output_prefix="output/cover")
dois = extract_doi_in_folder("output")
make_bibtex_db(dois)
