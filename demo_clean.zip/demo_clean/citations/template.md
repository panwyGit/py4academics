
---
title: Reference List,
subtitle: All citations from the BibTeX database,
csl: {csl_style}
bibliography: {fname}
---

# List Citations

{ref_list}

---

# References

::: {{#refs}}
:::
