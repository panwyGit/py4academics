import pathlib
import subprocess

fname = "references.bib"
csl_style = "harvard-cite-them-right.csl"
# csl_style = 'ieee.csl'


def make_citations():
    template = pathlib.Path("template.md").read_text()
    bibtex_txt = pathlib.Path(fname).read_text()

    bibitems = bibtex_txt.split("@article{")
    bibitems = [line.split(",")[0].strip() for line in bibitems]

    ref_list = ""
    for item in bibitems:
        if item:
            ref_list += f"- [@{item}]\n"

    filled_template = template.format(
        csl_style=csl_style, ref_list=ref_list, fname=fname
    )
    with open("references.md", "w") as f:
        f.write(filled_template)

    command = "pandoc references.md -o references.html --standalone --citeproc"
    subprocess.run(command, shell=True)


##################################
# MAIN
##################################
make_citations()
