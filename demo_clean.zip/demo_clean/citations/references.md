
---
title: Reference List,
subtitle: All citations from the BibTeX database,
csl: harvard-cite-them-right.csl
bibliography: references.bib
---

# List Citations

- [@Xie_2018]
- [@Yang_2019]
- [@Mart_n_Pomares_2017]
- [@Cui_2024]
- [@Yang_2018]
- [@Yang_2020]
- [@Liu_2021]
- [@Ineichen_2008]
- [@Eroshenko_2020]
- [@Urraca_2016]
- [@Antonanzas_2016]
- [@Omoyele_2024]
- [@Nouri_2025]
- [@Voyant_2018]
- [@Voyant_2017]
- [@Rahimi_2023]
- [@Zhang_2015]
- [@Torres_Lobera_2013]
- [@Terr_n_Serrano_2021]
- [@Gueymard_2008]
- [@Wang_2016]
- [@Kiss_2024]


---

# References

::: {#refs}
:::
