import pathlib
import pandas as pd
import matplotlib.pyplot as plt


def make_report(template_fname, data):
    with open(template_fname) as f:
        template = f.read()

    with open("report.html", "w") as f:
        f.write(template.format(**data))


def get_date_range():
    folder = pathlib.Path("weather_data")
    flist = sorted(list(folder.glob("*.csv")))
    start_date = flist[0].name.split(".")[0]
    end_date = flist[-1].name.split(".")[0]
    date_range = f"{start_date} - {end_date}"
    return date_range


def get_monthly_data():
    flist = pathlib.Path("weather_data").glob("*.csv")
    mins, maxs, totals = [], [], []
    for fpath in flist:
        df = pd.read_csv(fpath)
        mins.append(df.min_temp_c.min())
        maxs.append(df.max_temp_c.max())
        totals.append(df.rainfall_mm.sum())
    monthly = pd.DataFrame(
        {"temperature_min": mins, "temperature_max": maxs, "total_rain_fall": totals}
    )
    return monthly


monthly = get_monthly_data()
data = {
    "date_range": get_date_range(),
    "temperature_min": monthly.temperature_min.min(),
    "temperature_max": monthly.temperature_max.max(),
    "total_rain_fall": monthly.total_rain_fall.sum(),
    "temperature_trend": '<img src="temp_trend.png" alt="temperature trend">',
    "monthly_trend": monthly.to_html(),
    "today": "2026-06-08",
}

make_report("template.html", data)
