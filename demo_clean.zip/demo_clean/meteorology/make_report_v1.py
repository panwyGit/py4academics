def make_report(template_fname, data):
    with open(template_fname) as f:
        template = f.read()

    with open("report.html", "w") as f:
        f.write(template.format(**data))


data = {
    "date_range": "2025-01 - 2025-06",
    "temperature_min": 10,
    "temperature_max": 30,
    "total_rain_fall": 500,
    "temperature_trend": "UP",
    "monthly_trend": "No Good",
    "today": "2026-06-08",
}

make_report("template.html", data)
