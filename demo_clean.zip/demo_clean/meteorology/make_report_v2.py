import pathlib
import pandas as pd
import matplotlib.pyplot as plt


def make_report(template_fname, data):
    with open(template_fname) as f:
        template = f.read()

    with open("report.html", "w") as f:
        f.write(template.format(**data))


def get_date_range():
    folder = pathlib.Path("weather_data")
    flist = sorted(list(folder.glob("*.csv")))
    start_date = flist[0].name.split(".")[0]
    end_date = flist[-1].name.split(".")[0]
    date_range = f"{start_date} - {end_date}"
    return date_range


def get_temperatures_rainfall():
    flist = pathlib.Path("weather_data").glob("*.csv")
    mins, maxs, totals = [], [], []
    for fpath in flist:
        df = pd.read_csv(fpath)
        mins.append(df.min_temp_c.min())
        maxs.append(df.max_temp_c.max())
        totals.append(df.rainfall_mm.sum())
    return min(mins), max(maxs), sum(totals)


temperature_min, temperature_max, total_rain_fall = get_temperatures_rainfall()
data = {
    "date_range": get_date_range(),
    "temperature_min": temperature_min,
    "temperature_max": temperature_max,
    "total_rain_fall": total_rain_fall,
    "temperature_trend": "UP",
    "monthly_trend": "No Good",
    "today": "2026-06-08",
}

make_report("template.html", data)
