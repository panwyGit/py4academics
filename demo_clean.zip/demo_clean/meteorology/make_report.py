import pathlib
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns

sns.set_theme(style="whitegrid", palette="colorblind")


def make_report(template_fname, data):
    with open(template_fname) as f:
        template = f.read()

    with open("report.html", "w") as f:
        f.write(template.format(**data))


def get_date_range():
    folder = pathlib.Path("weather_data")
    flist = sorted(list(folder.glob("*.csv")))
    start_date = flist[0].name.split(".")[0]
    end_date = flist[-1].name.split(".")[0]
    date_range = f"{start_date} - {end_date}"
    return date_range


def get_monthly_data():
    flist = pathlib.Path("weather_data").glob("*.csv")
    months = []
    mins, maxs, totals = [], [], []
    for fpath in flist:
        df = pd.read_csv(fpath)
        months.append(fpath.name.split(".")[0])
        mins.append(df.min_temp_c.min())
        maxs.append(df.max_temp_c.max())
        totals.append(df.rainfall_mm.sum())
    monthly = pd.DataFrame(
        {
            "year_month": months,
            "temperature_min": mins,
            "temperature_max": maxs,
            "total_rain_fall": totals,
        }
    )
    monthly.year_month = pd.to_datetime(monthly.year_month, format="%Y-%m")
    monthly = monthly.sort_values(by="year_month")
    return monthly


def make_trend_png():
    fig, ax = plt.subplots()
    sns.lineplot(data=monthly, y="temperature_min", x="year_month", ax=ax)
    sns.lineplot(data=monthly, y="temperature_max", x="year_month", ax=ax)
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    plt.xticks(rotation=90)
    plt.savefig("temp_trend.png", bbox_inches="tight")


monthly = get_monthly_data()
make_trend_png()
data = {
    "date_range": get_date_range(),
    "temperature_min": monthly.temperature_min.min(),
    "temperature_max": monthly.temperature_max.max(),
    "total_rain_fall": monthly.total_rain_fall.sum(),
    "temperature_trend": '<img src="temp_trend.png" alt="temperature trend">',
    "monthly_trend": monthly.to_html(),
    "today": pd.Timestamp.today().floor("s"),
}

make_report("template.html", data)
