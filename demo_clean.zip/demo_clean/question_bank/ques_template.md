
{QNo}. {question}

-----  --------------
  A      {answerA}
  B      {answerB}
  C      {answerC}
  D      {answerD}
-----  --------------

