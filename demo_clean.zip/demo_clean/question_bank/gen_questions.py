from random import shuffle, choice
import subprocess


def mk_ques_specific_heat():
    title = "specific heat capacity"

    mg_mass = 2.4  # choice([2.4, 1.2, 4.8, 3.6])
    cu_so4_mol = 2.0
    cu_so4_vol = 100

    delta_T = 1.0  # choice([1.0, 0.8, 1.2, 1.5, 0.6])
    spc = 4.2
    mg_am = 24

    h2o_mass = cu_so4_vol
    heat_released = -h2o_mass * spc * delta_T

    mg_mol = mg_mass / mg_am
    heat_of_reaction = heat_released / mg_mol
    heat_of_reaction_kJ_per_mol = heat_of_reaction / 1000

    question = f"""In an experiment, {mg_mass} g of magnesium poweder is added to {cu_so4_vol} cm^3^ of {cu_so4_mol} mol dm^-1^ copper(II) sulphate solution.
    The temperature of the mixture increases by {delta_T} °C. What is the heat of reaction in the experiment? [Specific heat capacity of a solution = {spc} J g^-1^ °C^-1^; Relative atomic mass of Mg = 24]
"""
    correct_answer = f"{heat_of_reaction_kJ_per_mol:.2f} kJ mol^-1^"
    wrong_answer_1 = f"{heat_of_reaction_kJ_per_mol - 0.6:.2f} kJ mol^-1^"
    wrong_answer_2 = f"{heat_of_reaction_kJ_per_mol * 10:.2f} kJ mol^-1^"
    wrong_answer_3 = f"{(heat_of_reaction_kJ_per_mol - 0.6) * 10:.2f} kJ mol^-1^"

    options = ["A", "B", "C", "D"]
    answers = [correct_answer, wrong_answer_1, wrong_answer_2, wrong_answer_3]

    order = [0, 1, 2, 3]
    shuffle(order)

    ques = {
        "title": title,
        "question": question,
        "answerA": answers[order[0]],
        "answerB": answers[order[1]],
        "answerC": answers[order[2]],
        "answerD": answers[order[3]],
        "correct_answer": options[order.index(0)],
    }

    return ques


def make_all_questions(n_ques=5):
    with open("ques_template.md") as f:
        md_template = f.read()

    questions = ""
    answers = ""
    for i in range(1, n_ques + 1):
        ques = mk_ques_specific_heat()
        ques["title"] = ques["title"] + f" {i}"

        md = md_template.format(**ques, QNo=i)

        questions += md + "\n\n\n"
        answers += f'Q{i}. {ques["correct_answer"]} '

    with open("quizz_paper.md", "w") as f:
        f.write(questions)
    with open("quiz_answer.md", "w") as f:
        f.write(answers)

    command = "pandoc quizz_paper.md -o quizz_paper.html"
    subprocess.run(command, shell=True)
    command = "pandoc quizz_paper.md -o quizz_paper.docx"
    subprocess.run(command, shell=True)


####################
# MAIN
####################
make_all_questions()
